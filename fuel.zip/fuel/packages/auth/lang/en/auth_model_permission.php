<?php

return array(
    'area'        => 'Area name',
    'permission'  => 'Permission name',
    'description' => 'Description',
);
