<header id="header" class="header">
	<div class="m-header">
		<div class="t-header">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<?php
							if(!empty($dataText1)) {
							 	echo $dataText1;
							}
						?>
					</div>
				</div>
			</div>
		</div><!-- t-header -->
	</div><!-- m-header -->
</header><!-- header -->
