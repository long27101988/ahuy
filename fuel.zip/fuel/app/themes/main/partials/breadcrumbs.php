<section class="navigations">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<ul class="clearfix">
					<li><a href="#">HOME</a></li>
					<li><a href="#">DỰ ÁN</a></li>
				</ul>
			</div>
		</div>
	</div>
</section>