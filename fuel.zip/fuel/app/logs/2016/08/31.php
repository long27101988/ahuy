<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2016-08-31 17:30:27 --> Error - date_default_timezone_get(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/fuel.php on line 162
ERROR - 2016-08-31 17:31:18 --> Error - date_default_timezone_get(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/fuel.php on line 162
ERROR - 2016-08-31 17:31:39 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:39 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:39 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:39 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:40 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:41 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:31:43 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:12 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:12 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:12 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:12 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:15 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:15 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:15 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:15 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:16 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:16 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:16 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:16 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:16 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:16 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:16 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:16 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:17 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:18 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:18 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:18 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:18 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:33:33 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:33 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:33 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:33:33 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 106
ERROR - 2016-08-31 17:34:06 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:06 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:06 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:21 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:21 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:21 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:21 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/home/index.php on line 108
ERROR - 2016-08-31 17:34:27 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:27 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:27 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:30 --> Model_Base_Core:getRowNum:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:30 --> Model_Base_Core:getAll:112 - SQLSTATE[HY000] [2002] No such file or directory
ERROR - 2016-08-31 17:34:30 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/views/products/index.php on line 29
ERROR - 2016-08-31 17:37:41 --> Error - Could not find asset: add-1.png" in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-08-31 17:38:08 --> Error - Could not find asset: add-1.png" in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-08-31 17:38:16 --> Error - Could not find asset: add-1.png" in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-08-31 17:38:27 --> Error - Could not find asset: add-1.png" in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-08-31 17:39:30 --> Error - Could not find asset: add-1.png" in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-08-31 17:39:49 --> Error - Could not find asset: add-1.png" in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-08-31 17:41:37 --> Warning - The use statement with non-compound name 'Controller_AdminBase' has no effect in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/auth.php on line 7
ERROR - 2016-08-31 17:43:16 --> Warning - The use statement with non-compound name 'Controller_AdminBase' has no effect in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/auth.php on line 7
ERROR - 2016-08-31 17:45:24 --> Warning - The use statement with non-compound name 'Controller_AdminBase' has no effect in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/auth.php on line 7
ERROR - 2016-08-31 17:45:26 --> Warning - The use statement with non-compound name 'Controller_AdminBase' has no effect in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/auth.php on line 7
ERROR - 2016-08-31 17:45:26 --> Warning - The use statement with non-compound name 'Controller_AdminBase' has no effect in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/auth.php on line 7
ERROR - 2016-08-31 17:45:27 --> Warning - The use statement with non-compound name 'Controller_AdminBase' has no effect in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/auth.php on line 7
