<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2016-09-04 09:18:41 --> Error - The requested view could not be found: news/categories.php in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/view.php on line 477
ERROR - 2016-09-04 10:59:55 --> Notice - Undefined variable: listTags in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/add.php on line 57
ERROR - 2016-09-04 12:45:06 --> Error - The requested view could not be found: news/categories.php in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/view.php on line 477
ERROR - 2016-09-04 12:49:31 --> Error - The requested view could not be found: news/categories.php in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/view.php on line 477
ERROR - 2016-09-04 12:51:20 --> Notice - Undefined variable: listCategories in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/categories/add.php on line 24
ERROR - 2016-09-04 12:59:32 --> Notice - Undefined index: title in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/categories/index.php on line 30
ERROR - 2016-09-04 13:02:33 --> Notice - Undefined variable: newsinfo in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/categories/edit.php on line 2
ERROR - 2016-09-04 14:03:36 --> Notice - Undefined variable: newsinfo in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/categories/edit.php on line 2
ERROR - 2016-09-04 14:08:17 --> Notice - Undefined variable: newsinfo in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/categories/edit.php on line 2
ERROR - 2016-09-04 14:12:41 --> Notice - Undefined index: status in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/classes/controller/news.php on line 251
ERROR - 2016-09-04 14:34:07 --> Notice - Undefined index: name in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/tags/index.php on line 30
ERROR - 2016-09-04 14:34:30 --> Notice - Undefined index: name in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/tags/index.php on line 30
ERROR - 2016-09-04 14:36:15 --> Notice - Undefined variable: listCategories in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/tags/add.php on line 24
ERROR - 2016-09-04 15:17:45 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/classes/controller/news.php on line 243
ERROR - 2016-09-04 15:22:44 --> Warning - var_dump() expects at least 1 parameter, 0 given in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/classes/controller/news.php on line 53
ERROR - 2016-09-04 15:28:50 --> Fatal Error - Class 'Admin\DB' not found in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/classes/controller/news.php on line 94
ERROR - 2016-09-04 15:32:37 --> Parsing Error - parse error in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/modules/admin/views/news/edit.php on line 65
