<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2016-09-24 07:03:03 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/themes/main/partials/header.php on line 29
ERROR - 2016-09-24 07:04:52 --> Warning - Invalid argument supplied for foreach() in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/themes/main/partials/header.php on line 144
ERROR - 2016-09-24 07:27:20 --> Notice - Undefined offset: 7 in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 51
ERROR - 2016-09-24 15:13:33 --> Notice - Undefined offset: 9 in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 51
