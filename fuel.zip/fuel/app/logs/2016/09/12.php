<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2016-09-12 14:46:40 --> Parsing Error - parse error, expecting `']'' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 60
ERROR - 2016-09-12 14:47:07 --> Parsing Error - parse error in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 68
ERROR - 2016-09-12 14:48:00 --> Parsing Error - parse error in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 68
ERROR - 2016-09-12 14:49:45 --> Parsing Error - parse error in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 68
ERROR - 2016-09-12 14:49:46 --> Parsing Error - parse error in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 68
ERROR - 2016-09-12 14:49:47 --> Parsing Error - parse error in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 68
ERROR - 2016-09-12 14:50:10 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 14:50:10 --> Notice - Undefined index: price in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 65
ERROR - 2016-09-12 14:51:20 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 14:51:20 --> Notice - Undefined index: price in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 65
ERROR - 2016-09-12 14:52:37 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 14:52:49 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 14:54:37 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 14:55:08 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 14:55:23 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 14:56:07 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 14:56:54 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 14:57:19 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 14:57:23 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 14:58:05 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 14:59:55 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:00:03 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:02:23 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:02:35 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:02:56 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:03:00 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:03:01 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:03:01 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:03:01 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:03:32 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:04:00 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:05:53 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:06:52 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:07:13 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:07:57 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:08:03 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:08:04 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:08:33 --> Notice - Undefined index: shopping in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 49
ERROR - 2016-09-12 15:08:47 --> Notice - Undefined index: shopping in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 49
ERROR - 2016-09-12 15:11:46 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:15:13 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:15:19 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:15:21 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:15:22 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:15:23 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:17:35 --> Error - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on line 476
ERROR - 2016-09-12 15:17:35 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:18:38 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:18:59 --> Error - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on line 476
ERROR - 2016-09-12 15:18:59 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:20:10 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:21:55 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:22:24 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:23:47 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:23:48 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:23:48 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:23:48 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:23:48 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:24:35 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 51
ERROR - 2016-09-12 15:27:34 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 52
ERROR - 2016-09-12 15:27:39 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 52
ERROR - 2016-09-12 15:27:58 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 52
ERROR - 2016-09-12 15:28:09 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 52
ERROR - 2016-09-12 15:28:23 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 52
ERROR - 2016-09-12 15:29:50 --> Warning - Illegal string offset 'shopping' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 52
ERROR - 2016-09-12 15:31:05 --> Error - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on line 476
ERROR - 2016-09-12 15:31:05 --> shutdown - The session data stored by the application in the cookie exceeds 4Kb. Select a different session storage driver. in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/session/driver.php on 476
ERROR - 2016-09-12 15:31:48 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 15:31:48 --> Notice - Undefined index: price in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 73
ERROR - 2016-09-12 15:32:07 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 15:32:07 --> Notice - Undefined index: price in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 73
ERROR - 2016-09-12 15:33:54 --> Model_Base_Core:getOne:141 - Undefined variable: query
ERROR - 2016-09-12 15:33:54 --> Notice - Undefined index: price in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 73
ERROR - 2016-09-12 15:39:52 --> Notice - Undefined offset: 6 in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 52
ERROR - 2016-09-12 15:42:24 --> Notice - Undefined index: id in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:42:27 --> Notice - Undefined index: id in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:42:41 --> Notice - Undefined index: id in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:43:33 --> Parsing Error - parse error, expecting `"identifier (T_STRING)"' or `"variable (T_VARIABLE)"' or `"number (T_NUM_STRING)"' in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:44:13 --> Notice - Undefined index: id in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 50
ERROR - 2016-09-12 15:47:36 --> Notice - Undefined index: price in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/classes/controller/product.php on line 64
ERROR - 2016-09-12 16:02:17 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:03:22 --> Error - Could not find asset: /products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:03:24 --> Error - Could not find asset: /products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:03:58 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:03:59 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:04:00 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:04:00 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:04:00 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:04:00 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:04:01 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:04:03 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:04:30 --> Notice - Undefined variable: valproduct in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/themes/main/partials/header.php on line 34
ERROR - 2016-09-12 16:04:32 --> Notice - Undefined variable: valproduct in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/themes/main/partials/header.php on line 34
ERROR - 2016-09-12 16:04:44 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:35 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:36 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:36 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:37 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:37 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:37 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:37 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:38 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:05:45 --> Fatal Error - Class 'Assets' not found in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/app/themes/main/partials/header.php on line 34
ERROR - 2016-09-12 16:07:28 --> Error - Could not find asset: 7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:07:29 --> Error - Could not find asset: 7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:07:46 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:07:47 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:07:47 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:07:48 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:12:06 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
ERROR - 2016-09-12 16:14:56 --> Error - Could not find asset: products/7d63b1625c816c2.jpg in /Library/WebServer/Documents/daiphu/daiphu_project/fuel/core/classes/asset/instance.php on line 413
