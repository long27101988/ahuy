<style type="text/css">
	.welcome {
  font-size: 30px;
  margin-top: 10%;
  padding: 10px;
  text-align: center;
}
</style>
<div class="welcome">Welcome to dienlanhdaiphu.com</div>