<?php
echo 'default template';
echo $content;