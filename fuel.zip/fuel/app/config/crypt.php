<?php
return array(
  'crypto_key' => 'JBwErsPuc1F8bHstrMPUIeKE',
  'crypto_iv' => 'WN0IRkkQsglUCRYsfgo1QIwg',
  'crypto_hmac' => 'peA7VUHCgbdcnec5qEP40pJ0',
);
