	<?php
/**
 * The development database settings. These get merged with the global settings.
 */

return array(
	'default' => array(
		'connection'  => array(
			'dsn'        => 'mysql:host=127.7.242.130:3306;dbname=daiphudb',
			'username'   => 'admin5hAFhTy',
			'password'   => 'mqKL7VASRBhL',
		),
	),
);
